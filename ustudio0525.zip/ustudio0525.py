import sys
import time
import os
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLineEdit, QPushButton, QTextEdit, QMessageBox
from PyQt5.QtCore import Qt
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

class GoogleNewsSearcher(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("구글 뉴스 검색기")
        self.setGeometry(200, 200, 800, 600)  # 창 크기를 더 크게 조정
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("검색어를 입력하세요...")
        # Return 키 자동 연결 해제
        # self.search_input.returnPressed.connect(self.search_news)

        self.search_button = QPushButton("뉴스 검색")
        self.search_button.clicked.connect(self.search_news)

        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)  # 읽기 전용으로 설정
        self.result_text.setStyleSheet("""
            QTextEdit {
                background-color: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 4px;
                padding: 10px;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
        """)

        layout.addWidget(self.search_input)
        layout.addWidget(self.search_button)
        layout.addWidget(self.result_text)

        self.setLayout(layout)

    def search_news(self):
        print("검색 시작")  # 디버깅을 위한 로그 추가
        keyword = self.search_input.text().strip()
        if not keyword:
            QMessageBox.warning(self, "입력 오류", "검색어를 입력해주세요.")
            return

        # 브라우저 설정
        options = webdriver.ChromeOptions()
        options.add_argument("--headless")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        options.add_experimental_option('excludeSwitches', ['enable-logging', 'enable-automation'])
        options.add_experimental_option('useAutomationExtension', False)
        
        # webdriver-manager를 사용하여 ChromeDriver 자동 설치 및 관리
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)

        try:
            # 구글 뉴스 검색
            search_url = f"https://www.google.com/search?q={keyword}&tbm=nws"
            driver.get(search_url)
            
            # 명시적 대기 설정
            wait = WebDriverWait(driver, 10)
            news_items = wait.until(
                EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.dbsr, div.SoaBEf"))
            )

            self.result_text.clear()

            if not news_items:
                self.result_text.setHtml("<p style='color: #666;'>검색 결과가 없습니다.</p>")
                return

            # Markdown 형식의 HTML 생성
            html_content = f"<h2 style='color: #2c3e50; margin-bottom: 20px;'>'{keyword}' 검색 결과</h2>"
            html_content += "<div style='display: flex; flex-direction: column; gap: 15px;'>"

            for idx, item in enumerate(news_items[:10], 1):
                try:
                    # 새로운 HTML 구조에 맞게 선택자 수정
                    title = item.find_element(By.CSS_SELECTOR, "div.n0jPhd").text
                    link = item.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    
                    html_content += f"""
                    <div style='background-color: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);'>
                        <h3 style='color: #2c3e50; margin: 0 0 10px 0;'>{idx}. {title}</h3>
                        <a href='{link}' style='color: #3498db; text-decoration: none;'>{link}</a>
                    </div>
                    """
                except Exception as e:
                    print(f"항목 처리 중 오류: {str(e)}")
                    continue

            html_content += "</div>"
            self.result_text.setHtml(html_content)

        except Exception as e:
            QMessageBox.critical(self, "오류", f"검색 중 오류 발생:\n{str(e)}")
        finally:
            driver.quit()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GoogleNewsSearcher()
    window.show()
    sys.exit(app.exec_())
